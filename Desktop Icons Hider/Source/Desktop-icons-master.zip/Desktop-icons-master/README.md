# Desktop-Icons
An AHK (AutoHotKey) script that toggles whether desktop icons are shown/hidden.

To toggle whether desktop icons are shown/hidden press *win+alt+d*.

Keys chosen because *win+d* shows the the desktop and *win+ctrl+d* creates a new desktop.


This script definitely works for Windows 10. I'm not sure if it will work for other another OS.


To get this script to work each and every time you start your computer, place the executable in *'..\Microsoft\Windows\Start Menu\Programs\StartUp'*. Open run using *Win+R* and open *'shell:common startup'*.
