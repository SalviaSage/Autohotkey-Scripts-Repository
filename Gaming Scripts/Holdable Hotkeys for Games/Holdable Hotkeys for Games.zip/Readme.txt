Holdable Hotkeys for Games;

The idea behind this script is simple.
It lets you use "hold" hotkeys.

So for example, pressing the '9' key on the keyboard is difficult.
So we can set it so that the user can press the 'c' key and hold that key for half a second or a second.
Then, it will press the 9 key instead. That key can be set to another action.

This is useful for games that lets the user use a lot of different hotkeys.

Adapted from the "Typer Helper" program.