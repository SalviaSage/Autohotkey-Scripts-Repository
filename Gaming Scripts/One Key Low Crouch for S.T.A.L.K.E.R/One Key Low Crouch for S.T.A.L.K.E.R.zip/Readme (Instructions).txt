One key low crouch for S.T.A.L.K.E.R.;

In the game, you can perform a low crouch by first pressing the crouch key and then pressing the walk key.
Two keys have to be pressed in order to perform a low crouch.

This Autohotkey script makes it so that when you press the left alt key, it will also press the left control key at the same time.
This makes it so that you can do a normal crouch by pressing LEFT CTRL and a low crouch by pressing LEFT ALT.

For it to work, crouch has to be mapped to CTRL and walk has to be mapped to ALT in the options menu.

It does however otherwise take away the ability to walk.