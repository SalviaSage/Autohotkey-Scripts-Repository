Fast Apostrophe (Hair Spaced) (RTL Version) (No-Break);

This program is aimed at people who want to type orthographical marks appropriately.
It keeps the original keys of the keyboard and does not break anything but it adds some punctuation marks that are useful for typing languages.
To type these, just hold down the punctuation mark keys for a set amount of time.
It does not change the letters.

The difference with this one, compared with the regular version is that this version puts a very narrow space (hairspace) between quotation marks parentheses and brackets.

In the no-break version, when we do line breaks, the quotation marks and the brackets will not break at line breaks.
That is, the word will take the quotation marks and the brackets to the next line along with the word.
Which I think is the correct way of doing this.
This is necessary because the hairspace character will break the brackets and the quotation marks.
