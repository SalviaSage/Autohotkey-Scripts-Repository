Hold Capitals;

A computer program for typing capital letters more easily.
Basically, instead of holding down shift and pressing the letters, we hold down the letter for a set amount of time.

Has 250ms and 333ms versions.