Holdable ScrollLock v1.6;

Changes the default toggleable behaviour of Scroll-Lock to holdable.
Also, still retains the toggleable behaviour, but this is now toggled by hitting the scroll lock key twice, instead of once.
It has to be hit twice within 125ms to toggle.
Activated by default. You can suspend it by right clicking the program icon in the tray menu and hitting suspend.
