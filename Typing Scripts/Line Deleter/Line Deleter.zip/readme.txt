Line Deleter;

A small program for deleting words and lines in a quicker way.
Hold down the backspace for a quarter of a second or one third of a second to delete whole words.
Tap backspace twice and hold for a quarter of a second to delete the entire line in the text editor.
