This program is aimed at people who want to type math.
It keeps the original keys of the keyboard and thus does not break anything but it adds some keys that are useful for typing math.

For example, to type fractions type the number above, the numerator, then press and hold the slash key on the keyboard.
It will give you a 'fraction slash', then type the number that goes below, the denominator.
This helps with typing fractions appropriately.

Also, you can type the unequals sign, subtraction sign, the multiplication sign and the division sign by holding and tap holding the equals key on the keyboard.

You can type the degree sign by holding down the asterisk key on the keyboard.

Same goes for permil and per ten thousand symbols, located at the percent symbol.