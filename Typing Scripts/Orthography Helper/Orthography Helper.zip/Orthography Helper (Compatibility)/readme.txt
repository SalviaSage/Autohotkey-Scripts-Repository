Orthography Helper (Compatibility);
(Compatibility version for video games and other platforms where characters show up as empty squares.)

This program is aimed at people who want to type orthographical marks appropriately.
It keeps the original keys of the keyboard and does not break anything but it adds some punctuation marks that are useful for typing languages.
To type these, just hold down the punctuation mark keys for a set amount of time.
It does not change the letters.
